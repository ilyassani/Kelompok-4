<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>

	<h1> Login </h1>
	<form action="validasi_login.php" method="post">
		<table>
			<tr>
				<td>
					<input type="text" name="username" placeholder="Username">
				</td>
			</tr>
			<tr>
				<td>
					<input type="password" name="password" placeholder="Password">
				</td>
 			</tr>
			<tr>
				<td>
				<input type="submit">
				</td>
			</tr>
		</table>
	</form>
	<?php 
	 ?>	
</body>
</html>