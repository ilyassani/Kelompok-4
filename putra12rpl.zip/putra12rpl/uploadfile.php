<!DOCTYPE html>
<html>
<head>
	<title>Upload</title>
</head>
<body>
	
	<form action="" method="post">
		<input type="file" name="uploadFile">	
	</form>
</body>
</html>